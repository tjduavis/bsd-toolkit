#include <stdio.h>

void one(char* s);
void two(char* s);
void three(char* s);
void DoThis(char* s, void (*fptr)(char*));
int main(void)
{
  char s[11]="LSGWXGDUIV";
  DoThis(s,three);
  DoThis(s,one);
  DoThis(s,three);
  DoThis(s,two);
  DoThis(s,three);
}

void one(char* s){
  char* p1=s+1;
  for(char* p2=s;*p2!='\0';p2++,p1+=2){
    *p2=*p1;
  }
}
void two(char* s){
  for(char* p=s;*p!='\0';p++){
    *p=(*p)-2;
  }
}
void three(char* s){
  printf("Here: %s\n",s);
}
void DoThis(char* s, void (*fptr)(char*)){
  fptr(s);
}
