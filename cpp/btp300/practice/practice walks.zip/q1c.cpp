#include <stdio.h>
#include <string.h>
#define ABC(x) (x>=0)?x:-x
#define GO_UP i++
#define GO_DOWN i--
#define DOTHIS GO_UP
void f1(char* s){
  int i=0;
  int j;
  for(j=0;s[j]!='\0';j++){
    s[j]+=i;
    DOTHIS;
  }
}
int main(void)
{
	char s1[6]="KMMQO";
  char s2[6]="KHRBO";
  int i=3;
  printf("%d\n",ABC(7));
  printf("%d\n",ABC(7-2));
  f1(s1);
  printf("S1=%s\n",s1);
  #undef DOTHIS
  #define DOTHIS GO_DOWN
  f1(s2);
  DOTHIS;
  printf("S2=%s\n",s2);
  printf("%d\n",i);
}
