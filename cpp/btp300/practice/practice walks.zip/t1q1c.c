/* OOP344C TEST #1:  Friday June 21, 2002                         */
/* Name:             _________________________                    */
/* Student I.D.      _________________________                    */

/* Question 1. Walkthrough (25 Marks)                             */
/* Determine the exact output of the following C program.         */
/* Alphabet is: ABCDEFGHIJKLMNOPQRSTUVWXYZ                        */
/* required ASCII values: 'A'=65, 'a'=97, '`'=96, ' '=32, '!'=33  */

#include <stdio.h>

#define AUX
#define ROW 3
#define COL 4
#define MOV(a, b) (a < 32) ? a << b : 2

typedef struct {
   int x, y;
   char (*s)[ROW][COL]; /* 's' points to 1 or more 2D arrays */
} word;

void process(word *, int);

int main( ) {
   char w[24] = { 
                  'B', 'm', 'n', 'd', 'l', 'm', 'd', ' ', 'E', 'u', 'o', '`',
                  'f', 'n', 'f', ' ', 'A', 'q', '`', 'z', 'h', 'k', 'd', ' '
                };
   word a;
   a.x = 1;
   a.y = 1;
   a.s = (char (*)[ROW][COL])w;    /* casts 'w' into 1 or more pages with   */
                                   /* each page having dimensions ROW x COL */
   process(&a, sizeof(w));
   printf("%c\n", *(*(*(a.s+1)+2)+3));
   return 0;
}

void process(word *p, int n) {
   int i, j, k, div=1;
   for(i=0; i < n/(ROW*COL); i++) {
      for(j=0; j < ROW; j++) {
         for(k=0; k < COL; k++, div++) {
                                   /* don't forget to increment 'div' */
            p->x = MOV(p->x, p->y);
            if(div%8 == 0 && div < n) {
               printf("\n");
            }
            else {
               p->s[i][j][k] = p->s[i][j][k] - (p->x/div) + p->y;
 
               #ifdef AUX          /* recall: these are PRE-PROCESSOR      */
                                   /* directives and are evaluated BEFORE  */
                                   /* ANY C code compilation!              */
                  printf("%c", p->s[i][j][k]);
                  #undef AUX
               #else
                  p->s[i][j][k]++;
               #endif
            }
         }
      }
   }
}
