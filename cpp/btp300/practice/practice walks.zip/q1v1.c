/* OOP344CE Winter 2003 Test #1
Student Name ____________________ Student # ______________ Sect__

Question 1. Walkthrough (20 Marks). Determine the exact
output of the following C program. You MUST show your rough
work to receive FULL/PART marks.
ALPHABET is: ABCDEFGHIJKLMNOPQRSTUVWXYZ 'A' = 65 'a' = 97 */

#include <stdio.h>

/*#define T*/
#define SZ 6
#define CH(a) (a) ^ 32

typedef enum { AIX, HPUX, OSX=5, IRIX, SOLARIS, LINUX } OS;
typedef struct {
   char *p;
   unsigned pos:4;   /* NOTE: 'pos' is a bit-field */
   OS type;
} mfr;

void init(mfr *, char[ ][10], int);
void proc(mfr *);

int main( ) {
   char data[SZ][10] = { "Macintosh", "IBMachine", "HewlettPa",
                         "GPLicense", "SunMicros", "SiliconGX" };
   mfr list[SZ];
   OS x;
   int i, index, shift[9] = { 3, 6, -16, 4, 5, 1, -3, -6 };

   init(list, data, SZ);
   printf("%d", SZ);
   for(i=0, x=LINUX; x>AIX; x--, i++) {
      index = (x >= SZ) ? x-OSX : x;
      printf("%c", index == 4 ?
                 CH(list[index].p[list[index].type] + shift[i]) :
                 list[index].p[list[index].type] + shift[i]);
   }
   return 0;
}
void init(mfr *p_mfr, char s[ ][10], int n) {
   for(--n; n>=0; n--) {  /* be careful, it's not ++ */
      p_mfr->p    = s[n];
      p_mfr->pos  = n;
      p_mfr->type = n < 4 ? OSX + n : OSX - n ;
      printf("init[%s:%d:%d]\n", p_mfr->p, p_mfr->pos, p_mfr->type);

      #ifdef T        /* NOTE: preprocessor statements are        */
         proc(p_mfr); /*       evaluated before code is compiled! */
      #endif
      p_mfr++;
   }
}
void proc(mfr *p_mfr) {
   p_mfr->p[p_mfr->type] += p_mfr->pos;
   printf("proc[%s:%d:%d]\n", p_mfr->p, p_mfr->pos, p_mfr->type);
}
