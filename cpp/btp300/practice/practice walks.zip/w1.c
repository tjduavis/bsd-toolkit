/* This question also located on phobos: */
/* /home/dabesdri/oop444/oop444_011testq1b.c */

/* OOP444 Winter 2001 Test #1 Question 1. (25 Marks) */
/* Determine the exact output of the following C program */
/* You MUST show your rough work to receive FULL/PARTIAL marks */

/* Name__________________  Student# _ _ _-_ _ _-_ _ _ Section OOP444 _ */

#include <stdio.h>
typedef struct {
   unsigned int x : 1;
   char *p;
} crypt;

#define SZ 2
#define LIM SZ*(SZ+1)*(SZ+2)
#define MOVE(a, b) (a) < 4 ? (a) >> (b) : (a) << (b)

typedef enum { R=-2, O, Y, G, B=0, I, V, UV } spectra;
void acs(crypt *, char *);
void fac(const char *, int);

int main( ) {
   char data[SZ][SZ+1][SZ+2] =
      { { {'3','2','3','?'},  {'2','4','4','?'}, {'4','3','?','\0'} },
        { {'3','\0','/','w'}, {'h','o','/','b'}, {'w','k','\0','\0'} }
      };
   crypt y;
   y.x = 0;
   acs(&y, (char *)data);
   fac((char *)data, sizeof(data));
   return 0;
}

void acs(crypt *sec, char *s) {
   int i, ch, j=0, offset[10] = {1,-1,3,0,-1,0,-5,0,1,0};
   
   char junk[LIM+1]="AxtgFhtXtk2pQ:tNLEDxyG//";
   spectra x;
   sec->p = s;
   for(i=0, x=G; i<LIM; i++, s++) { /* be careful when incrementing */
      if(*s=='4' || !*s)
         printf("%c", junk[i]);
      if(*s=='?') {
         *(sec->p) = '.';
      }
      else {
         if(*s >= '0' && *s <= '9') {
            ch = MOVE(*(sec->p)-'0', x);
            *s = ch + '0' + offset[j++];
         }
      }
      sec->p++;
   }
}

void fac(const char *str, int sz) {
   int i;
   for(i=0; i<sz; i++) {
      if(str[i])
         printf("%c", str[i]);
   }
}

