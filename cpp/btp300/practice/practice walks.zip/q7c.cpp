//What is the output of the following program? 
//Also, on the indicated lines, state the element 
//referred to in array notation.


#include <iostream>
using namespace std;
int main(void)
{
	char grid[2][3][5]={
    {"mint","rose","iris"},
    {"lily","leaf","stem"},
                     };
  cout << *(*(grid+1)+2)+1;
  cout << (char)(*(*(*(grid)+1)+1)+1);
  cout << *(*(*(grid+1)+1));     //In Array notation:     
  cout << *(*(*(grid+1))+7);          
  cout << *(*(*(grid+1)+2)+1);   //In Array notation:
  cout << *(*(*(grid+1)+1)+1);   //In Array notation:
  cout << endl;
}
