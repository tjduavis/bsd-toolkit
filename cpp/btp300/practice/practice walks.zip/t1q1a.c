/* OOP344A TEST #1:  Thursday June 20, 2002                       */
/* Name:             _________________________                    */
/* Student I.D.      _________________________                    */

/* Question 1. Walkthrough (25 Marks)                             */
/* Determine the exact output of the following C program.         */
/* Alphabet is: ABCDEFGHIJKLMNOPQRSTUVWXYZ                        */

#include <stdio.h>

typedef struct {
   int x, y;
   char *s;
} word;

#define AUX
#define GO(a, b) (a < 32) ? a << b : 2

void process(word *, int);

int main( ) {
   char w[2][3][4] = { 
                       { { 'N', 'b', 'y', 'l' },
                         { 'r', 't', 'r', ' ' },
                         { 'D', 'g', 'b', 'h' }
                       },
                       { { 'l', 'u', 't', ' ' },
                         { 'L', 'd', 'q', 'i' },
                         { 'c', 'h', 't', 'r' }
                       }
                     };
   word a;
   a.x = 1;
   a.y = 1;
   a.s = (char *) w;      /* be careful of the cast here          */
   process(&a, sizeof(w));
   printf("%c\n", *(*(*(w+1)+2)+3) + 1);
   return 0;
}

void process(word *p, int n) {
   int i;
   for(i=1; i<n; i++, p->s++) {
      p->x = GO(p->x, p->y);
      if(i%8==0) {
         printf("\n");
      }
      else {
         *(p->s) = *(p->s) - (p->x/i) + p->y;
         #ifdef AUX       /* recall, these are PRE-PROCESSOR      */
                          /* directives, and are evaluated BEFORE */
                          /* ANY C code compilation!              */
            printf("%c", *(p->s));
            #undef AUX
         #else
            *(p->s)++;
         #endif
      }
   }
}