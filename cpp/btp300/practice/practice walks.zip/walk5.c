
/* Walkthrough:  walk5.c */
/* From:         oop444t1.973 /home/weaver/public/old_tests/ */
/* Written By:   Evan Weaver */

/*
Determine the exact output of the following program. Show your
rough work if you expect any part marks. Be as precise as possible
and be careful about the case (upper- or lower-) of your answer.

You need to know the ASCII code of a space is 32, the alphabet is
ABCDEFGHIJKLMNOPQRSTUVWXYZ, and the ASCII codes of the letters
(A is 65, B is 66, etc. and a is 97, b is 98, etc.)
*/

#include <stdio.h>

#define SZ 3
char print(char c) {
   return c >= ' ' && c <= '~' ? c : '#';
}

void fooey(char *in, char *out, int size) {
   char (*p)[SZ]; /* p points to array[s] of SZ chars each */
   int r, c, i;

   p = (char (*)[SZ])in;
   for(c = i = 0; c < SZ; c++)
      for(r = 0; r < size/SZ; r++, i++) {
	 out[i] = p[r][c] && p[r][c] != ' ' ? (p[r][c] | ' ') + 1 : p[r][c];
	 printf("%d=%c,(%d,%d)=%c\n",
		  i, print(out[i]), r, c, print(p[r][c]));
     }
}

int main( ) {
   char test[9] = "NFCGNX N",
	test2[sizeof test];

   fooey(test, test2, sizeof test);
   printf("%s\n", test2);
   return 0;
}
