There are 4 programs to the main.  indexer (similar but not
identical to version with preliminary main), checkindex (run this to find
if your hash table is correctly build after you index it .  I will use
this and the indexer program to determine if your assignment is complete),
searchexp1, and searchexp2 which allow you to experience with various
cache sizes.

Indexer creates an index of the words found in 8 files.
It keeps track of how many times each word appears in 
each of the files.  Once it is completed, you can test to
see if the table was properly built and play around with various cache sizes.
                                                    
NOTE:  If you run the indexermore than once, all  
       the counts will double so you need to remove 
       the old data file before running this again  

Put your source in this directory before you compile
I have included a compilation script files which
you may use if you wish.  compile.bat uses the bcc32
compiler.

