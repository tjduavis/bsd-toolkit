package com.aurifa.struts2.tutorial.service;

import java.util.List;

public interface DepartmentService {
    public List getAllDepartments();
}
