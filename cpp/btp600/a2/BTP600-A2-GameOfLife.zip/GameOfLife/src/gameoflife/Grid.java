/*
 * Grid.java
 *
 * Created on 2007�� 4�� 7�� (��), ���� 7:01
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package gameoflife;
import java.awt.Color;
/**
 *
 * @author Administrator
 */
public class Grid {
    Cell[][] myCells; 
    int rowSize;
    int colSize;
    int age;
    /** Creates a new instance of Grid */
    public Grid(int recRowSize, int recColSize) {
        age = 0;
        rowSize = recRowSize;
        colSize = recColSize;
        myCells = new Cell[recRowSize + 2][recColSize + 2];
        for (int row = 0; row < myCells.length; row++) {
            for (int col = 0; col < myCells[row].length; col++) {
                myCells[row][col] = new Cell();
            }
        }
    }
    public int getRow() {
        return rowSize;
    }
    public int getCol() {
        return colSize;
    }    
    public Color getColor(int recRow, int recCol) {
        Color returnValue = null;
        if (recRow >= 0 && recRow <= rowSize && recCol >= 0 && recCol <= colSize) { 
            
            returnValue = myCells[recRow][recCol].getState().stateColor();
        }
        return returnValue;
    }
    public Cell getCell(int recRow, int recCol) {return myCells[recRow][recCol];}
    public Cell[][] getCells() {return myCells;}  
    public int getAge() {return age;}
    public void addAge() { age++; }
    public void clearGameBoard() {
        age = 0;
        for (int r = 0; r < rowSize; r++) {
            for (int c = 0; c < colSize; c++) {
                getCell(r, c).killThisCell();
            }
        }
    
    }  
    public void setGrid(Grid grid) {
        this.myCells = grid.getCells();
    }        
    public void cellClicked(int recRow, int recCol) {myCells[recRow][recCol].thisCellClicked();}
    public Generation createGenerator() {
        return new Generation(this);
    }    
}
