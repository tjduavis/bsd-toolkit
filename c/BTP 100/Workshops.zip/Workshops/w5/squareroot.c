#include<math.h>

int main(void)
{	
	double a, b=16;

	a=sqrt(b);
	printf("%lf\n",a);
	
	return 0;
}