/*
*  Workshop 7 - Assets	
*  loading function
*	loads users input for price and quantity 
*	in parrallel array with barcode.
*/

void loading(barcode[],price[],quantity[],int x)
{

	printf("Price:");
	scanf("%f",&price[x]);
			
	/*validation*/
	
	printf("Quantity:");
	scanf("%d",&quantity[x]);

	/*validation*/
}