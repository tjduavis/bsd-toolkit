main()
{
 long long upc;
 int chk; 
 
 printf("Enter your digits");
 scanf("%lld\n",&upc);
 
 chk=upc%10;
 printf("\ndigit number one is%d\n",chk);
}